# SAMR34 platform support documents

The supported SAMR34 platform can be evaluated via SAMR34-XPRO evaluation kit [User Guide](http://ww1.microchip.com/downloads/en/DeviceDoc/SAM-R34-Xplained-Pro-User-Guide-DS50002803C.pdf)

The SAM R34 family data sheet can be found at [SAM R34 Family Data Sheet](http://ww1.microchip.com/downloads/en/DeviceDoc/SAMR34-R35-Low-Power-LoRa-Sub-GHz-SiP-Data-Sheet-DS70005356B.pdf)
